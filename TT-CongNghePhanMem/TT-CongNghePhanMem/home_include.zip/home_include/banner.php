﻿
		<div id="lg-header">
			<h1><a href="#">logo</a></h1>
		</div><!-- End .bg-lg-header -->
		<div id="bg-header">
		</div><!-- End .bg-header -->