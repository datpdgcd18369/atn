                <div id="menu">
					<ul>
						<li><a href="index.php">TRANG CHỦ</a></li>
						<li><a href="index.php?content=gioithieu">GIỚI THIỆU</a></li>
						<li><a href="index.php?content=sanpham">SẢN PHẨM</a>
						<li><a href="index.php?content=phukien">PHỤ KIỆN</a></li>
						<li><a href="index.php?content=khuyenmai">KHUYỂN MÃI</a></li>
						<li><a href="index.php?content=tintuc">TIN TỨC</a></li>
						<li><a href="index.php?content=hotro">HỖ TRỢ</a></li>
					</ul>
				</div>